<?php

return [
    'MODULE_NAME' => 'docs',
];