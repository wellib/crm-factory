<?php

return [
    'MODULE_NAME' => 'Документооборот',

    'INVALID_CONFIG_MESSAGE__UPLOAD_DIRECTORY_IS_NOT_EXIST' => 'Каталог для загрузки изображений не существует!',
];