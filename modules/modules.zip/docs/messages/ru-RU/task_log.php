<?php

return [
    'ATTR__COMMENT__LABEL' => 'Комментарий',
    'ATTR__REASON__LABEL' => 'Причина',
    'ATTR__ATTACHEDFILESUPLOAD__LABEL' => 'Прикрепить файлы',
];