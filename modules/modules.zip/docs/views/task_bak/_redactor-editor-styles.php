<?php

/* @var $this yii\web\View */

?>

<?php $this->registerCss("
    /* Editor default content styles */
    .redactor-editor {
        //font-family: 'Times New Roman' !important;
        font-size: 15px !important;
    }
    .redactor-editor div, .redactor-editor p, .redactor-editor ul, .redactor-editor ol, .redactor-editor table, .redactor-editor dl, .redactor-editor blockquote, .redactor-editor pre {
        font-size: 15px !important;
        line-height: 1;
        margin-bottom: 0;
        text-align: justify;
    }
") ?>
