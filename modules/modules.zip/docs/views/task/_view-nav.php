<?php

use app\modules\docs\models\Task;
use yii\bootstrap\Tabs;
use yii\widgets\Menu;

/** @var $model Task */

?>

