<?php

return [
    'MODEL_NAME'        => 'Данные для предприятия',
    'MODEL_NAME_PLURAL' => 'Данные для предприятия',


    'ATTR__EMPLOYEE_ID__LABEL'            => 'Табельный номер',
    'ATTR__BIOMETRICS_ID__LABEL'          => 'ID биометрии',
    'ATTR__CONTRACT_NUMBER__LABEL'        => 'Номер договора',
    'ATTR__CONTRACT_DATE__LABEL'          => 'Дата договора ',
    'ATTR__EMPLOYMENT_DATE__LABEL'        => 'Дата приема',
    'ATTR__STRUCTURE_DEPARTMENT__LABEL'   => 'Компания / Отдел',

    'DATE__VALIDATE_MESSAGE__BAD_DATE'=> 'Дата должна быть в формате {format}',

    'ACCORDION_PANEL_HEADER_TITLE' => 'Данные для предприятия',
];
