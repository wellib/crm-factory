<?php

return [
    'MODEL_NAME'        => 'Поиск сотрудников',
    'MODEL_NAME_PLURAL' => 'Поиск сотрудников',


    'ATTR__FULL_NAME__LABEL'              => 'ФИО',
    'ATTR__STRUCTURE_DEPARTMENT__LABEL'   => 'Компания/Отдел',
    'ATTR__POSITION__LABEL'               => 'Должность',
    'ATTR__CONTACTS__LABEL'               => 'Основной контакт',
    'ATTR__EMPLOYEE_ID__LABEL'            => 'Табельный номер',

];
