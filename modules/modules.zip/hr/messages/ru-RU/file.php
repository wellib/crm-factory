<?php

return [
    'MODEL_NAME' => 'Файл',
    'MODEL_NAME_PLURAL' => 'Файлы',

    'ATTR__ID__LABEL' => 'ID',

    'ATTR__CREATED_AT__LABEL' => 'Добавлен',
    'ATTR__UPDATED_AT__LABEL' => 'Последнее изменение',

    'ATTR__FILE__LABEL'  => 'Файл',
    'ATTR__DESCRIPTION__LABEL' => 'Описание',

    'ACCORDION_PANEL_HEADER_TITLE' => 'Документы',

    'HTTP_ERROR__NOT_FOUND' => 'Ой :( Такого файла не существует, возможно он был удален или еще не загружен!',
];
