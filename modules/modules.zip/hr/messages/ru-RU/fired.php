<?php

return [
    'MODEL_NAME'        => 'Увольнение',
    'MODEL_NAME_PLURAL' => 'Увольнения',

    'ATTR__DATE__LABEL'               => 'Дата увольнения',
    'ATTR__BASED_ON_DOCUMENTS__LABEL' => 'Основание (документ, номер, дата)',
    'ATTR__BASE_DISMISSAL__LABEL'     => 'Основание увольнения',

    'DATE__VALIDATE_MESSAGE__BAD_DATE' => 'Дата должна быть в формате {format}',
];
