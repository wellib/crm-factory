<?php

return [
    'MODULE_NAME' => 'Отдел кадров',
];