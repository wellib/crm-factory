<?php

return [
    'MODEL_NAME'        => 'Прием на работу',
    'MODEL_NAME_PLURAL' => 'Прием на работу',

    'ATTR__PROBATION_MONTHS__LABEL' => 'Испытательный срок (в месяцах)',

    'ATTR__EMPLOYMENT__LABEL' => 'Условия приема на работу',
    'EMPLOYMENT__FILL_TIME__LABEL' => 'Полное рабочее время',
    'EMPLOYMENT__PART_TIME__LABEL' => 'Не полное рабочее время',

    'ATTR__EMPLOYMENT_TERM__LABEL' => 'Характер работы',
    'ATTR__DATE_BEGIN__LABEL' => 'Дата начала работы',
    'ATTR__DATE_END__LABEL' => 'Дата окончания работы',

    'DATE__VALIDATE_MESSAGE__BAD_DATE' => 'Дата должна быть в формате {format}',


    'ACCORDION_PANEL_HEADER_TITLE' => 'Прием на работу',
];
