<?php

return [
    'MODEL_NAME'        => 'Стаж работы',
    'MODEL_NAME_PLURAL' => 'Стаж работы',

    'ATTR__START_DATE__LABEL'       => 'Начало',
    'ATTR__END_DATE__LABEL'         => 'Окончание',
    'ATTR__ORGANIZATION__LABEL'     => 'Название организации',
    'ATTR__POSITION__LABEL'         => 'Должность',
    'ATTR__DISMISSAL_REASON__LABEL' => 'Причина увольнения',


    'ACCORDION_PANEL_HEADER_TITLE' => 'Стаж работы',
];
