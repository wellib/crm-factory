<?php

return [
    'MODEL_NAME'        => 'Контакт',
    'MODEL_NAME_PLURAL' => 'Контакты',

    'ATTR__TYPE__LABEL'        => 'Тип',
    'ATTR__VALUE__LABEL'       => 'Контакт',
    'ATTR__DESCRIPTION__LABEL' => 'Описание',
    'ATTR__MAIN__LABEL'        => 'Основной',

    'ACCORDION_PANEL_HEADER_TITLE' => 'Контакты',
];
