<?php

return [
    'MODEL_NAME'        => 'Образование',
    'MODEL_NAME_PLURAL' => 'Образование',

    'ATTR__INSTITUTION__LABEL'     => 'Место обучения',
    'ATTR__GRADUATION_YEAR__LABEL' => 'Год окончания',
    'ATTR__CERTIFICATED__LABEL'    => 'Серия и № диплома',
    'ATTR__DEGREE__LABEL'          => 'Ученая степень',
    'ATTR__SPECIALTY__LABEL'       => 'Специальность',


    'ACCORDION_PANEL_HEADER_TITLE' => 'Образование',
];
