<?php

return [
    'MODEL_NAME'        => 'Родственник',
    'MODEL_NAME_PLURAL' => 'Родственники',

    'ATTR__KINSHIP__LABEL'    => 'Степень родства',
    'ATTR__FULL_NAME__LABEL'  => 'ФИО',
    'ATTR__BIRTH_DATE__LABEL' => 'Дата рождения',
    'ATTR__NOTE__LABEL'       => 'Примечание',


    'ACCORDION_PANEL_HEADER_TITLE' => 'Семья и родственники',
];
