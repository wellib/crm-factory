<?php

return [
    'MODULE_NAME' => 'Human Resources',
];